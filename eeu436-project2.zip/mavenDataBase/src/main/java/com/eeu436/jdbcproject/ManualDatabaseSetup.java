package com.eeu436.jdbcproject;

import static com.eeu436.jdbcproject.MySQLTester.showResultSet;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * Mini Project 2: Java Database
 * Class:  Database Setup Handler
 * Purpose: Sets up the database for the assignment.
 * Date: 02/13/2016
 * 
 * @author EEU436
 */
public class ManualDatabaseSetup {
    
    InputStream stream;
    Connection conn;
    
    /**
     * Constructor, initializes DB connection.
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public ManualDatabaseSetup() throws IOException, ClassNotFoundException, SQLException{
        
        stream = MySQLTester.class.getResourceAsStream("/database.properties");
        SimpleDataSource.init(stream);
	conn = SimpleDataSource.getConnection();
    }
    
    /**
     * Creates tables in Uni of Utopia DB.
     * @return
     * @throws FileNotFoundException
     * @throws SQLException 
     */
    public boolean createTables() throws FileNotFoundException, SQLException{
     
        //wrap in try, catch later
        Scanner in = null;
        try{
            in = new Scanner(new File("src/main/resources/2-create.sql"));
        
        }catch(FileNotFoundException ex){
            System.out.println(ex);
        }
        try{
            Statement stat = conn.createStatement();      
            while (in.hasNextLine()){
            
                String line = in.nextLine();
            
                try{
                    boolean hasResultSet = stat.execute(line);
                
                    if (hasResultSet){
                        try (ResultSet result = stat.getResultSet()) {
                            showResultSet(result);
                        }
                    }
                }
                catch (SQLException ex){
                    System.out.println(ex);
                    in.close();
                    return false;
                }
            }
        }
        finally{      
            conn.close();
            in.close();
            return true;
        }
    }
    
    /**
     * Adds seed-data to tables.
     * @return
     * @throws SQLException
     * @throws FileNotFoundException 
     */
    public boolean addSeedData() throws SQLException, FileNotFoundException{
        
        Scanner in =  new Scanner(new File("src/main/resources/3-insert.sql"));
        
        try{
            Statement stat = conn.createStatement();      
            while (in.hasNextLine()){
            
                String line = in.nextLine();
            
                try{
                    boolean hasResultSet = stat.execute(line);
                
                    if (hasResultSet){
                        try (ResultSet result = stat.getResultSet()) {
                            showResultSet(result);
                        }
                    }
                }
                catch (SQLException ex){
                    System.out.println(ex);
                    return false;
                }
            }
        }
        finally{      
            conn.close();
            in.close();
            return true;
        }   
    }
    
    /**
     * Drops (pre-existing) tables.
     * @return
     * @throws FileNotFoundException
     * @throws SQLException 
     */
    public boolean destroyTables() throws FileNotFoundException, SQLException{
        
        Scanner in =  new Scanner(new File("src/main/resources/1-destroy.sql"));
        
        try{
            Statement stat = conn.createStatement();      
            while (in.hasNextLine()){
            
                String line = in.nextLine();
            
                try{
                    boolean hasResultSet = stat.execute(line);
                
                    if (hasResultSet){
                        try (ResultSet result = stat.getResultSet()) {
                            showResultSet(result);
                        }
                    }
                }
                catch (SQLException ex){
                    System.out.println(ex);
                    return false;
                }
            }
        }
        finally{      
            conn.close();
            in.close();
            return true;
        }   
    }
}
