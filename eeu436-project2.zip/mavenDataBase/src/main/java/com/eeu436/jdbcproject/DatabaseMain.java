package com.eeu436.jdbcproject;

/**
 * ICP 2052 - Mini Project 2: JDBC
 * Date: 02/13/2016
 * Class: DatabaseMain
 * Purpose: Entry point for JDBC Application.
 * 
 * @author Dorian Dressler (eeu436)
 */
public class DatabaseMain {
    
    public static void main(String[] args){

         DatabaseTextInterface dbInterface = new DatabaseTextInterface();
    }
}
