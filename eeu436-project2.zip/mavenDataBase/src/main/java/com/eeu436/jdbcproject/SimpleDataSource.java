package com.eeu436.jdbcproject;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Mini Project 2 - Exercise 1
 * Class: SimpleDataSource
 * Date: 3/02/2016
 * 
 * @author EEU436
 */
public class SimpleDataSource {
    
    /**
    * Initializes the data source.
    * @param stream
    * @throws java.io.IOException
    * @throws java.lang.ClassNotFoundException
    */
    public static void init(InputStream stream) throws IOException,
            ClassNotFoundException{
		
        Properties props = new Properties();
        
        try{
            props.load(stream);
        
            String driver = props.getProperty("jdbc.driver");
            url = props.getProperty("jdbc.url");
            username = props.getProperty("jdbc.username");
            password = props.getProperty("jdbc.password");
            Class.forName(driver);
        
        }catch(NullPointerException e){
            
            System.out.println("Exception " + e + " caught");
        }
    }

    /**
    * Gets a connection to the database.
    * @return the database connection
    * @throws java.sql.SQLException
    */
    public static Connection getConnection() throws SQLException {
  
        return DriverManager.getConnection(url, username, password); 
    }
	
    private static String url;
    private static String username;
    private static String password;
}
