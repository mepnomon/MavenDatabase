package com.eeu436.jdbcproject;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * ICP 2052 - Mini Project 2: JDBC
 * Date: 02/13/2016
 * Class: DatabaseTextInterface
 * Purpose: Command Line Interface for JDBC Project.
 * 
 * @author Dorian Dressler (eeu436)
 */
public class DatabaseTextInterface {
   
    DatabaseManager dbManager;
    Scanner sc;
    
    /**
     * Constructor.
     */
    public DatabaseTextInterface(){
        
        dbManager = new DatabaseManager();
        sc = new Scanner(System.in);
        mainMenuInterface();
    }
       
    /**
     * The main menu is the main access pont for the user/
     * The user is presented with a choice of tables to query,
     * view reports and quit the application.
     */
    private void mainMenuInterface(){
        
        boolean done = false;
        
        while(!done){
            //printMainMenu();
            System.out.print("\n\nMain Menu\n*********\n1. Students\n2. Modules"
                + "\n3. Registrations\n4. Staff\n5. Taught by staff"
                + "\n6. Reports\n0. Quit\n\n:>");
            try{
                //get user input
                switch(sc.nextInt()){
                    
                    case 0: System.out.println("System exit"); done=true; break; // should also close connection
                    case 1: subMenuInterface("student");done=true ;break;
                    case 2: subMenuInterface("module");done=true ;break;
                    case 3: subMenuInterface("registered");done=true ;break;
                    case 4: subMenuInterface("staff");done=true ;break;
                    case 5: subMenuInterface("teaches");done=true ;break;
                    case 6: reportSubMenu(); break;
                    default:;
                }
            }catch(InputMismatchException e){
                System.out.print(e + "\nInvalid Input: enter an integer.");
                sc = new Scanner(System.in);
           }
        }
    }
    
    /**
     * This is the sub menu interface, the user reaches after he 
     * selects a general class of query from the main menu. Excluding 'Reports'.
     * The user is prompted with data manipulation and query choices.
     * @param tableName the name of the table queried by the user.
     */
    private void subMenuInterface(String tableName){
        
        boolean done = false;
        String id, id2;
        
        while(!done){
            System.out.print("\n\nSub-Menu ("+ tableName + " table)\n************\n1. Add "
                    + tableName + "\n2. Remove "+ tableName+ ""
                    + "\n3. Update "+ tableName +"\n4. List " + tableName + " table\n0. "
                    + "Return to main menu\n:>");
            try{
                switch(sc.nextInt()){ //find common factors and cut down!
                    case 0: done=true; mainMenuInterface(); break;
                    case 1: addTableSubMenu(tableName); break;
                    case 2: //deletion
                            sc.nextLine();
                            id2 = null;
                            if(tableName.equals("registered") || tableName.equals("teaches")){ // revise SQL statement for this
                                //sc.nextLine();
                                System.out.printf("Deleting from %s\n", tableName); 
                                System.out.print("ID:");
                                id = sc.nextLine();
                                System.out.println("2nd ID:");
                                id2 = sc.nextLine();
                                dbManager.deleteRecord(tableName, id, id2);
                            } else{
                                System.out.printf("Deleting from %s\n", tableName); 
                                System.out.print("ID: ");
                                id = sc.nextLine();
                                dbManager.deleteRecord(tableName, id, null);
                            }
                            break;
                    case 3: updateTableSubMenu(tableName); break;
                    case 4: printResultSet(dbManager.showTable(tableName)); break;
                }
            }catch(SQLException e){
                System.out.println("Exception caught: " + e);
            }catch(InputMismatchException e){
                System.out.print(e + "\nInvalid Input: enter an integer.");
                sc = new Scanner(System.in);
            }
        }
    }
    
    /**
     * Helper method, manages sub-menu for adding record to table.
     * @param tableName the table the user is querying.
     * @throws SQLException is thrown up to the next level.
     */
    private void addTableSubMenu(String tableName) throws SQLException{
       
        String param3 = null;
        String id, id2, name, optionalParam;
        if(tableName.equals("student") || tableName.equals("staff") || tableName.equals("module")){    
            
            switch(tableName){
                case "student": param3 = "Degree: "; break;
                case "staff":   param3 = "Grade: "; break;
                case "module": param3 = "Credits: "; break;
            }
            sc.nextLine(); //clears sc
            System.out.print("ID: ");
            id = sc.nextLine();
            System.out.print("Name: ");
            name = sc.nextLine();
            System.out.print(param3);
            optionalParam = sc.nextLine();
                            dbManager.addRecord(tableName, id, name, optionalParam);
                            
        }else{
            String param1 = null;
            String param2 = null;
            
            switch(tableName){
                case "teaches": param1 = "Staff ID: "; 
                    param2 = "Module ID:";break;
                case "registered": param1 = "Student ID: "; 
                     param2 = "Module ID: "; break;
            }
            sc.nextLine();
            System.out.print(param1);
            id = sc.nextLine();
            System.out.print(param2);
            name = sc.nextLine(); //name var abused
            optionalParam = null; // set to null
            dbManager.addRecord(tableName, id, name, optionalParam);
        }            
    }
    
    /**
     * Takes user input to update columns in selected table.
     * @param tableName the name of the table the user is updating.
     * @throws SQLException is thrown to the next higher level.
     */
    private void updateTableSubMenu(String tableName) throws SQLException{ //test and verify
        String studentID = null;
        String oldModuleID = null;
        String newModuleID = null;
        int flagChoice;
        
        sc.nextLine();
        if(tableName.equals("registered") || tableName.equals("teaches")){
            
            if(tableName.equals("registered")){
                System.out.println("Updating Student-module registration by student ID.");
            } else {
                System.out.println("Updating Staff-Teaches registration by Staff ID.");
            }
            System.out.print("Enter Personal ID: ");
            studentID = sc.nextLine();
            System.out.print("Enter current module ID: ");
            oldModuleID = sc.nextLine();
            System.out.print("Enter new module ID:");
            newModuleID = sc.nextLine();
            dbManager.updateTable(tableName, studentID, oldModuleID, newModuleID, 0);
            
        } else {
            
            System.out.print("\nUpdating " + tableName + " details\nSelect:\n1:"
                    + "Name\n2:Scheme\n3:Both\n:>");
            flagChoice = sc.nextInt();
            sc.nextLine();//clear scanner
            switch(flagChoice){ 
                
                case 1: System.out.print("Enter ID: "); studentID = sc.nextLine();
                        System.out.print("Enter new name: "); newModuleID = sc.nextLine(); 
                        dbManager.updateTable(tableName, studentID, null, 
                                newModuleID, flagChoice);break;
                    
                case 2: System.out.print("Enter ID: "); studentID = sc.nextLine();
                        System.out.print("Enter new scheme: "); newModuleID = sc.nextLine();
                        dbManager.updateTable(tableName, studentID, studentID, 
                                newModuleID, flagChoice);break;
                    
                case 3: System.out.print("Enter ID: "); studentID = sc.nextLine();
                        System.out.print("Enter new name: "); oldModuleID = sc.nextLine();
                        System.out.print("Enter new scheme: "); newModuleID = sc.nextLine();
                        dbManager.updateTable(tableName, studentID, oldModuleID, 
                                newModuleID, flagChoice); break; 
            }
        }
    }
    
    /**
     * This is the sub-menu interface for reports.
     * The user can choose the type of report he would like to view and
     * supply appropriate parameters. Input mismatches return to main menu.
     */
    private void reportSubMenu(){
        boolean done = false;
        String name;
        while(!done){
            //sc.nextLine(); //clear scanner
            System.out.print("\n\nReports\n*******\n1.Modules taught by\n2.Students "
                    + "registered on\n3.Staff who teach students"
                    + "\n4.Staff who teach more than\n0.Return to main menu\n:>");
            try{  
                switch(sc.nextInt()){ //change to user choice and recycle?
                    case 1: sc.nextLine();
                        System.out.print("Enter staff name:>"); name = sc.nextLine();
                        printResultSet(dbManager.generateReport(1, name)); break;

                    case 2: sc.nextLine(); System.out.print("Enter module name:> ");
                            name = sc.nextLine(); 
                            printResultSet(dbManager.generateReport(2, name));break;

                    case 3: sc.nextLine();
                        System.out.print("Enter student name:>"); name = sc.nextLine();
                        printResultSet(dbManager.generateReport(3, name)); break;

                    case 4: printResultSet(dbManager.generateReport(4, null)); break;

                    case 0: done=true;break;
                }
            }catch(SQLException e){System.out.println(e + " caught");}
        }
    }
    
    /**
     *This method prints the requested ResultSets.
     * @param rs The resultSet that is returned from a query.
     * @throws java.sql.SQLException are dealt with in the main menu.
     */
    public void printResultSet(ResultSet rs) throws SQLException{
        
        String columnName = null;;
        ResultSetMetaData metaData = rs.getMetaData();
        System.out.println("\n");
        for(int i = 1; i <= metaData.getColumnCount(); i++){
            
            columnName = metaData.getColumnLabel(i);;
            if(i > 1) System.out.print("\t");        
                
            switch(i){
                    case 1: System.out.printf("%-10s", columnName);break;
                    case 2: System.out.printf("%-25s", columnName);break;
                    case 3: System.out.printf("%-10s", columnName);break;
                }
            
        }
        System.out.println(); // prints and formats asterisks
        for(int i = 1; i <= metaData.getColumnCount(); i++ ){
            
            columnName = metaData.getColumnLabel(i);
            switch(i){
                case 2: System.out.printf("%-7s", "");break;
                case 3: System.out.printf("%-20s", "");break;
            }
            for(int j = 0; j <= columnName.length();j++){
                System.out.print("*");
            }
        }
        System.out.println();
        
        while(rs.next()){
            for(int i = 1; i <= metaData.getColumnCount(); i++){
                
                if(i > 1) System.out.print("\t");
                
                switch(i){
                    case 1: System.out.printf("%-10s", rs.getString(i));break;
                    case 2: System.out.printf("%-25s", rs.getString(i));break;
                    case 3: System.out.printf("%-10s", rs.getString(i));break;
                }
            }
            System.out.println();
        }
        rs.close();
    }
}