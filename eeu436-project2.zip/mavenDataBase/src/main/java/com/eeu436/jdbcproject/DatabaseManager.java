package com.eeu436.jdbcproject;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ICP 2052 - Mini Project 2: JDBC
 * Class: DatabaseManager
 * Date: 02/13/2016
 * Purpose: Class that manages DB operations
 * for DatabaseTextInterface
 * 
 * @author Dorian Dressler (eeu436)
 */
public class DatabaseManager {
    
    /**
     * Constructor.
     * Initializes connection to mySQL DB.
     */
    public DatabaseManager() {
        
        try {
            InputStream stream = MySQLTester.class.getResourceAsStream("/database.properties");
            SimpleDataSource.init(stream);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(DatabaseManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * make generic
     * @param tableName
     * @return
     * @throws SQLException 
     */
    public ResultSet showTable(String tableName) throws SQLException{
        
        ResultSet rs;
        Connection conn = SimpleDataSource.getConnection();
        Statement stat = conn.createStatement();
        String query = String.format("SELECT * FROM %s", tableName);
        return rs = stat.executeQuery(query);
    }
    
    /**
     * Allows users to add records to
     * predefined table.
     * @param tableName name of the table.
     * @param id id of the record to be added
     * @param name generic for the name variable
     * @param thirdParam a third parameter, this is something the records do not share.
     * @throws SQLException
     */
    public void addRecord(String tableName, String id, String name, 
            String thirdParam) throws SQLException{
       
        String col1 = null;
        String col2 = null;
        String col3 = null;
        
        Connection conn = SimpleDataSource.getConnection();
        Statement stat = conn.createStatement();
               
        if(tableName.equals("teaches") || tableName.equals("registered")){
           
            switch(tableName){
                
                case "registered": col1 = "student_Id"; col2 = "module_Id";break;               
                case "teaches": col1 = "staff_Id"; col2 = "module_Id"; break;
            }
            String command = String.format("INSERT INTO `%s` (`%s`, `%s`) "
                    + "VALUES ('%s', '%s')", tableName, col1, col2, id, name);
            stat.execute(command);
        
        } else {
            
            switch(tableName){
            
                case "student": col1 = "student_Id"; col2 = "student_name"; 
                                col3 = "degree_scheme"; break;
                case "staff": col1 = "staff_Id"; col2 = "staff_name"; 
                                col3 = "grade";break;
                case "module": col1 = "module_Id"; col2 = "module_name"; 
                                col3 = "credits"; break;          
            }
            String command = 
                    String.format("INSERT INTO `%s` (`%s`, "
                        + "`%s`, `%s`) VALUES "
                        + "('%s', '%s', '%s');",tableName, col1, col2, col3, 
                        id, name, thirdParam); 
            stat.execute(command);
            conn.close();
        }
    }
    
    /**
     * Removes a record from the table.
     * I assume that every deletion will be done via the ID.
     * I do this to rule out errors that could arise from
     * common last names, e.g. 'Smith'.
     * @param tableName the name of the table
     * @param id the ID of the entry
     * @param id2 second id for an entry with 2 Primary keys.
     * @throws java.sql.SQLException
     */
    public void deleteRecord(String tableName, String id, String id2) 
            throws SQLException{
        
        String command = null;
        String idColumn = null;
        String idColumn2 = null;
               
        Connection conn = SimpleDataSource.getConnection();
        Statement stat = conn.createStatement();        
        
        switch(tableName){
            
            case "student": idColumn = "student_Id"; break;
            case "staff":   idColumn = "staff_Id";  break;
            case "module":  idColumn = "module_Id"; break;
            case "teaches": 
                break;
            case "registered": //select relationship by student and module
                break;       
        }
        if(tableName.equals("teaches") || tableName.equals("registered")){ 
            command = 
                String.format("DELETE FROM `%s` where `%s` = '%s';", 
                        tableName, idColumn, id, id2);
        } else {            
            command = 
                String.format("DELETE FROM `%s` where `%s` = '%s';", 
                        tableName, idColumn, id);
        }
        stat.executeUpdate(command);
        conn.close();      
    }
    
    /**
     * Updates existing table entries.
     * @param tableName
     * @param id
     * @param oldData
     * @param newData
     * @param numOfParameters
     * @throws java.sql.SQLException
     */
    public void updateTable(String tableName, String id, String oldData, 
            String newData, int numOfParameters) throws SQLException{
        
        Connection conn = SimpleDataSource.getConnection();
        Statement stat = conn.createStatement();        
        String command = null;
        String primaryKey = null;
        String param1 = null;
        String param2 = null;
        
        if(tableName.equals("registered") || tableName.equals("teaches")){
            //only allows changing student or staff value by module id
            if(tableName.equals("registered")){
                primaryKey = "student_Id";
            } else { 
                primaryKey = "staff_Id";
            }
            command = String.format("UPDATE `%s` set `module_Id` = '%s' "
                    + "where `module_Id` = '%s' AND `%s` = '%s'", 
                    tableName, newData, oldData, primaryKey, id);
            stat.executeUpdate(command);
        
        } else { //other tables
            
            switch(tableName){
                case "student": primaryKey = "student_Id";
                    param1 = "student_name"; param2 = "degree_scheme"; break;
                case "module": primaryKey = "module_Id";
                    param1 = "module_name"; param2 = "credits"; break;
                case "staff" : primaryKey = "staff_Id";
                    param1 = "staff_name"; param2 = "grade"; break;
               }
            String statement = "UPDATE `%s` set `%s` = '%s' where `%s` = '%s'";
            switch(numOfParameters){ //add support for double param change
                case 1: command = String.format(statement, tableName, param1, newData, 
                        primaryKey, id);break;
                case 2: 
                    command = String.format(statement, tableName, param2, newData, 
                            primaryKey, id);break;
                case 3: 
                    command = String.format(statement, tableName, param1, 
                            oldData, param2, newData, primaryKey, id);break;
            }
            stat.execute(command);
            conn.close();
        } 
    }
    
    /**
     * Generates a report based on the user's choice.
     * @param userChoice used for the switch statement
     * @param name parameter supplied by the user.
     * @return rs a ResultSet containing the returned info for the query.
     * @throws SQLException 
     */
    public ResultSet generateReport(int userChoice, String name) throws SQLException{
        
        ResultSet rs;
        String tblAndCol = "`%s`.`%s` ";
        String from = "from `%s`";
        String joiner = "inner join `%s` on `%s`.`%s` = `%s`.`%s` ";
        String whereStatement = "where `%s` IN (select `%s` from `%s` where `%s` = '%s')";
        String query = null;
        String tbl1, tbl2, tbl3, tbl4, col1,col2,col3,col4, col5;
        Connection conn = SimpleDataSource.getConnection();
        Statement stat = conn.createStatement();
        
        switch(userChoice){ //could also use tableName and change variables
            
            case 1: query  = String.format("Select `teaches`.`module_Id`, "
                    + "`module`.`module_name` from `teaches` inner join `module`"
                    + " on `teaches`.`module_Id` = `module`.`module_Id` where "
                    + "`staff_Id` IN (select `staff_Id` from `staff` where " //could combine
                    + "`staff_name` = '%s')", name); 
                        break; 
       
            case 2: 
                query = String.format("Select `registered`.`student_Id`, "
                        + "`student`.`student_name` from `registered` "
                        + "inner join `student` on `registered`.`student_Id` "
                        + "= `student`.`student_Id` where `module_Id` IN "
                        + "(Select `module_Id` from `module` where `module_name` = '%s')", name); 
                        break;
            case 3: 
                    query = String.format("Select `r`.`module_Id`, `t`.`staff_Id`,"
                    + " `st`.`staff_name` from `registered` `r` "
                    + "inner join `teaches` `t` on `r`.`module_Id` = `t`.`module_Id`"
                    + " inner join `staff` `st` on `t`.`staff_Id` = `st`.`staff_Id`"
                    + " where `student_Id` IN (Select `student_Id` from `student`"
                    + " where `student_name` = '%s')", name); break;
                    
            case 4: query = String.format("Select `teaches`.`staff_Id`, "
                    + "`staff`.`staff_name` from `teaches` inner join `staff` on "
                    + "`teaches`.`staff_Id` = `staff`.`staff_Id` group by `staff_Id`"
                    + " having count(`staff`.`staff_Id`) > 1"); break;
        }
        return rs = stat.executeQuery(query);
    }
}