DROP TABLE IF EXISTS `teaches`, `registered`, `module`, `staff`, `student`;
